/*
 * helikopter_ex3.c
 *
 * Code generation for model "helikopter_ex3".
 *
 * Model version              : 1.61
 * Simulink Coder version : 8.6 (R2014a) 27-Dec-2013
 * C source code generated on : Fri Apr 22 13:27:25 2016
 *
 * Target selection: quarc_win64.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: 32-bit Generic
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */
#include "helikopter_ex3.h"
#include "helikopter_ex3_private.h"
#include "helikopter_ex3_dt.h"

/* Block signals (auto storage) */
B_helikopter_ex3_T helikopter_ex3_B;

/* Continuous states */
X_helikopter_ex3_T helikopter_ex3_X;

/* Block states (auto storage) */
DW_helikopter_ex3_T helikopter_ex3_DW;

/* Real-time model */
RT_MODEL_helikopter_ex3_T helikopter_ex3_M_;
RT_MODEL_helikopter_ex3_T *const helikopter_ex3_M = &helikopter_ex3_M_;

/*
 * Writes out MAT-file header.  Returns success or failure.
 * Returns:
 *      0 - success
 *      1 - failure
 */
int_T rt_WriteMat4FileHeader(FILE *fp, int32_T m, int32_T n, const char *name)
{
  typedef enum { ELITTLE_ENDIAN, EBIG_ENDIAN } ByteOrder;

  int16_T one = 1;
  ByteOrder byteOrder = (*((int8_T *)&one)==1) ? ELITTLE_ENDIAN : EBIG_ENDIAN;
  int32_T type = (byteOrder == ELITTLE_ENDIAN) ? 0: 1000;
  int32_T imagf = 0;
  int32_T name_len = (int32_T)strlen(name) + 1;
  if ((fwrite(&type, sizeof(int32_T), 1, fp) == 0) ||
      (fwrite(&m, sizeof(int32_T), 1, fp) == 0) ||
      (fwrite(&n, sizeof(int32_T), 1, fp) == 0) ||
      (fwrite(&imagf, sizeof(int32_T), 1, fp) == 0) ||
      (fwrite(&name_len, sizeof(int32_T), 1, fp) == 0) ||
      (fwrite(name, sizeof(char), name_len, fp) == 0)) {
    return(1);
  } else {
    return(0);
  }
}                                      /* end rt_WriteMat4FileHeader */

/*
 * This function updates continuous states using the ODE1 fixed-step
 * solver algorithm
 */
static void rt_ertODEUpdateContinuousStates(RTWSolverInfo *si )
{
  time_T tnew = rtsiGetSolverStopTime(si);
  time_T h = rtsiGetStepSize(si);
  real_T *x = rtsiGetContStates(si);
  ODE1_IntgData *id = (ODE1_IntgData *)rtsiGetSolverData(si);
  real_T *f0 = id->f[0];
  int_T i;
  int_T nXc = 5;
  rtsiSetSimTimeStep(si,MINOR_TIME_STEP);
  rtsiSetdX(si, f0);
  helikopter_ex3_derivatives();
  rtsiSetT(si, tnew);
  for (i = 0; i < nXc; i++) {
    *x += h * f0[i];
    x++;
  }

  rtsiSetSimTimeStep(si,MAJOR_TIME_STEP);
}

/* Model output function */
void helikopter_ex3_output(void)
{
  /* local block i/o variables */
  real_T rtb_FromWorkspace1[4];
  real_T rtb_Saturation_p;
  real_T rtb_Gain2;
  real_T rtb_HILReadEncoder_o1;
  real_T rtb_HILReadEncoder_o2;
  real_T rtb_HILReadEncoder_o3;
  real_T rtb_Gain[6];
  real_T rtb_VandringDeriv;
  real_T rtb_TransferFcn4;
  real_T tmp[6];
  int32_T i;
  int32_T i_0;
  real_T rtb_Sum2_idx_0;
  real_T rtb_Sum2_idx_2;
  if (rtmIsMajorTimeStep(helikopter_ex3_M)) {
    /* set solver stop time */
    if (!(helikopter_ex3_M->Timing.clockTick0+1)) {
      rtsiSetSolverStopTime(&helikopter_ex3_M->solverInfo,
                            ((helikopter_ex3_M->Timing.clockTickH0 + 1) *
        helikopter_ex3_M->Timing.stepSize0 * 4294967296.0));
    } else {
      rtsiSetSolverStopTime(&helikopter_ex3_M->solverInfo,
                            ((helikopter_ex3_M->Timing.clockTick0 + 1) *
        helikopter_ex3_M->Timing.stepSize0 +
        helikopter_ex3_M->Timing.clockTickH0 *
        helikopter_ex3_M->Timing.stepSize0 * 4294967296.0));
    }
  }                                    /* end MajorTimeStep */

  /* Update absolute time of base rate at minor time step */
  if (rtmIsMinorTimeStep(helikopter_ex3_M)) {
    helikopter_ex3_M->Timing.t[0] = rtsiGetT(&helikopter_ex3_M->solverInfo);
  }

  if (rtmIsMajorTimeStep(helikopter_ex3_M)) {
    /* S-Function (hil_read_encoder_block): '<S2>/HIL Read Encoder' */

    /* S-Function Block: helikopter_ex3/Heli 3D/HIL Read Encoder (hil_read_encoder_block) */
    {
      t_error result = hil_read_encoder(helikopter_ex3_DW.HILInitialize_Card,
        helikopter_ex3_P.HILReadEncoder_channels, 3,
        &helikopter_ex3_DW.HILReadEncoder_Buffer[0]);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(helikopter_ex3_M, _rt_error_message);
      } else {
        rtb_HILReadEncoder_o1 = helikopter_ex3_DW.HILReadEncoder_Buffer[0];
        rtb_HILReadEncoder_o2 = helikopter_ex3_DW.HILReadEncoder_Buffer[1];
        rtb_HILReadEncoder_o3 = helikopter_ex3_DW.HILReadEncoder_Buffer[2];
      }
    }

    /* Gain: '<S2>/Kalibrer-Elev' */
    helikopter_ex3_B.KalibrerElev = helikopter_ex3_P.KalibElevasjon *
      rtb_HILReadEncoder_o3;

    /* Sum: '<Root>/Add' incorporates:
     *  Constant: '<Root>/Constant'
     */
    helikopter_ex3_B.Add = helikopter_ex3_B.KalibrerElev +
      helikopter_ex3_P.Constant_Value;

    /* Gain: '<S2>/Kalibrer-Pitch' */
    helikopter_ex3_B.KalibrerPitch = helikopter_ex3_P.KalibPitch *
      rtb_HILReadEncoder_o2;

    /* ToFile: '<Root>/To File' */
    {
      if (!(++helikopter_ex3_DW.ToFile_IWORK.Decimation % 1) &&
          (helikopter_ex3_DW.ToFile_IWORK.Count*2)+1 < 100000000 ) {
        FILE *fp = (FILE *) helikopter_ex3_DW.ToFile_PWORK.FilePtr;
        if (fp != (NULL)) {
          real_T u[2];
          helikopter_ex3_DW.ToFile_IWORK.Decimation = 0;
          u[0] = helikopter_ex3_M->Timing.t[1];
          u[1] = helikopter_ex3_B.KalibrerPitch;
          if (fwrite(u, sizeof(real_T), 2, fp) != 2) {
            rtmSetErrorStatus(helikopter_ex3_M,
                              "Error writing to MAT-file PitchDataE1.mat");
            return;
          }

          if (((++helikopter_ex3_DW.ToFile_IWORK.Count)*2)+1 >= 100000000) {
            (void)fprintf(stdout,
                          "*** The ToFile block will stop logging data before\n"
                          "    the simulation has ended, because it has reached\n"
                          "    the maximum number of elements (100000000)\n"
                          "    allowed in MAT-file PitchDataE1.mat.\n");
          }
        }
      }
    }
  }

  /* TransferFcn: '<S2>/Vandring Lavpass' */
  helikopter_ex3_B.VandringLavpass = 0.0;
  helikopter_ex3_B.VandringLavpass += helikopter_ex3_P.VandringLavpass_C *
    helikopter_ex3_X.VandringLavpass_CSTATE;
  if (rtmIsMajorTimeStep(helikopter_ex3_M)) {
  }

  /* Integrator: '<S1>/Integrator'
   *
   * Regarding '<S1>/Integrator':
   *  Limited Integrator
   */
  if (helikopter_ex3_X.Integrator_CSTATE >= helikopter_ex3_P.Integrator_UpperSat
      ) {
    helikopter_ex3_X.Integrator_CSTATE = helikopter_ex3_P.Integrator_UpperSat;
  } else if (helikopter_ex3_X.Integrator_CSTATE <=
             (helikopter_ex3_P.Integrator_LowerSat) ) {
    helikopter_ex3_X.Integrator_CSTATE = (helikopter_ex3_P.Integrator_LowerSat);
  }

  rtb_Saturation_p = helikopter_ex3_X.Integrator_CSTATE;
  if (rtmIsMajorTimeStep(helikopter_ex3_M)) {
    /* Gain: '<S2>/Kalibrer -Vandring' */
    helikopter_ex3_B.KalibrerVandring = helikopter_ex3_P.KalibVandring *
      rtb_HILReadEncoder_o1;
  }

  /* TransferFcn: '<S2>/Vandring Deriv' */
  rtb_VandringDeriv = helikopter_ex3_P.VandringDeriv_C *
    helikopter_ex3_X.VandringDeriv_CSTATE + helikopter_ex3_P.VandringDeriv_D *
    helikopter_ex3_B.KalibrerVandring;

  /* TransferFcn: '<S2>/Transfer Fcn4' */
  rtb_TransferFcn4 = helikopter_ex3_P.TransferFcn4_C *
    helikopter_ex3_X.TransferFcn4_CSTATE + helikopter_ex3_P.TransferFcn4_D *
    helikopter_ex3_B.KalibrerPitch;

  /* TransferFcn: '<S2>/Transfer Fcn5' */
  rtb_Gain2 = 0.0;
  rtb_Gain2 += helikopter_ex3_P.TransferFcn5_C *
    helikopter_ex3_X.TransferFcn5_CSTATE;
  rtb_Gain2 += helikopter_ex3_P.TransferFcn5_D * helikopter_ex3_B.KalibrerElev;

  /* SignalConversion: '<Root>/TmpSignal ConversionAtGainInport1' */
  tmp[0] = helikopter_ex3_B.VandringLavpass;
  tmp[1] = rtb_VandringDeriv;
  tmp[2] = helikopter_ex3_B.KalibrerPitch;
  tmp[3] = rtb_TransferFcn4;
  tmp[4] = helikopter_ex3_B.Add;
  tmp[5] = rtb_Gain2;

  /* Gain: '<Root>/Gain' */
  for (i = 0; i < 6; i++) {
    rtb_Gain[i] = 0.0;
    for (i_0 = 0; i_0 < 6; i_0++) {
      rtb_Gain[i] += helikopter_ex3_P.Gain_Gain[6 * i_0 + i] * tmp[i_0];
    }
  }

  /* End of Gain: '<Root>/Gain' */

  /* Sum: '<S1>/Sum' incorporates:
   *  Constant: '<Root>/elevation'
   */
  rtb_Gain2 = helikopter_ex3_P.elevation_Value - rtb_Gain[4];

  /* Gain: '<S1>/K_ei' */
  helikopter_ex3_B.K_ei = helikopter_ex3_P.K_ei * rtb_Gain2;

  /* Sum: '<S1>/Sum1' incorporates:
   *  Gain: '<S1>/K_ed'
   *  Gain: '<S1>/K_ep'
   */
  rtb_Saturation_p = (helikopter_ex3_P.K_ep * rtb_Gain2 + rtb_Saturation_p) +
    -helikopter_ex3_P.K_ed * rtb_Gain[5];

  /* Saturate: '<S1>/Saturation' */
  if (rtb_Saturation_p > helikopter_ex3_P.Saturation_UpperSat) {
    rtb_Saturation_p = helikopter_ex3_P.Saturation_UpperSat;
  } else {
    if (rtb_Saturation_p < helikopter_ex3_P.Saturation_LowerSat) {
      rtb_Saturation_p = helikopter_ex3_P.Saturation_LowerSat;
    }
  }

  /* End of Saturate: '<S1>/Saturation' */

  /* FromWorkspace: '<Root>/From Workspace' */
  {
    real_T *pDataValues = (real_T *)
      helikopter_ex3_DW.FromWorkspace_PWORK.DataPtr;
    real_T *pTimeValues = (real_T *)
      helikopter_ex3_DW.FromWorkspace_PWORK.TimePtr;
    int_T currTimeIndex = helikopter_ex3_DW.FromWorkspace_IWORK.PrevIndex;
    real_T t = helikopter_ex3_M->Timing.t[0];

    /* Get index */
    if (t <= pTimeValues[0]) {
      currTimeIndex = 0;
    } else if (t >= pTimeValues[140]) {
      currTimeIndex = 139;
    } else {
      if (t < pTimeValues[currTimeIndex]) {
        while (t < pTimeValues[currTimeIndex]) {
          currTimeIndex--;
        }
      } else {
        while (t >= pTimeValues[currTimeIndex + 1]) {
          currTimeIndex++;
        }
      }
    }

    helikopter_ex3_DW.FromWorkspace_IWORK.PrevIndex = currTimeIndex;

    /* Post output */
    {
      real_T t1 = pTimeValues[currTimeIndex];
      real_T t2 = pTimeValues[currTimeIndex + 1];
      if (t1 == t2) {
        if (t < t1) {
          rtb_Gain2 = pDataValues[currTimeIndex];
        } else {
          rtb_Gain2 = pDataValues[currTimeIndex + 1];
        }
      } else {
        real_T f1 = (t2 - t) / (t2 - t1);
        real_T f2 = 1.0 - f1;
        real_T d1;
        real_T d2;
        int_T TimeIndex= currTimeIndex;
        d1 = pDataValues[TimeIndex];
        d2 = pDataValues[TimeIndex + 1];
        rtb_Gain2 = (real_T) rtInterpolate(d1, d2, f1, f2);
        pDataValues += 141;
      }
    }
  }

  /* FromWorkspace: '<Root>/From Workspace1' */
  {
    real_T *pDataValues = (real_T *)
      helikopter_ex3_DW.FromWorkspace1_PWORK.DataPtr;
    real_T *pTimeValues = (real_T *)
      helikopter_ex3_DW.FromWorkspace1_PWORK.TimePtr;
    int_T currTimeIndex = helikopter_ex3_DW.FromWorkspace1_IWORK.PrevIndex;
    real_T t = helikopter_ex3_M->Timing.t[0];

    /* Get index */
    if (t <= pTimeValues[0]) {
      currTimeIndex = 0;
    } else if (t >= pTimeValues[140]) {
      currTimeIndex = 139;
    } else {
      if (t < pTimeValues[currTimeIndex]) {
        while (t < pTimeValues[currTimeIndex]) {
          currTimeIndex--;
        }
      } else {
        while (t >= pTimeValues[currTimeIndex + 1]) {
          currTimeIndex++;
        }
      }
    }

    helikopter_ex3_DW.FromWorkspace1_IWORK.PrevIndex = currTimeIndex;

    /* Post output */
    {
      real_T t1 = pTimeValues[currTimeIndex];
      real_T t2 = pTimeValues[currTimeIndex + 1];
      if (t1 == t2) {
        if (t < t1) {
          {
            int_T elIdx;
            for (elIdx = 0; elIdx < 4; ++elIdx) {
              (&rtb_FromWorkspace1[0])[elIdx] = pDataValues[currTimeIndex];
              pDataValues += 141;
            }
          }
        } else {
          {
            int_T elIdx;
            for (elIdx = 0; elIdx < 4; ++elIdx) {
              (&rtb_FromWorkspace1[0])[elIdx] = pDataValues[currTimeIndex + 1];
              pDataValues += 141;
            }
          }
        }
      } else {
        real_T f1 = (t2 - t) / (t2 - t1);
        real_T f2 = 1.0 - f1;
        real_T d1;
        real_T d2;
        int_T TimeIndex= currTimeIndex;

        {
          int_T elIdx;
          for (elIdx = 0; elIdx < 4; ++elIdx) {
            d1 = pDataValues[TimeIndex];
            d2 = pDataValues[TimeIndex + 1];
            (&rtb_FromWorkspace1[0])[elIdx] = (real_T) rtInterpolate(d1, d2, f1,
              f2);
            pDataValues += 141;
          }
        }
      }
    }
  }

  /* Sum: '<Root>/Sum2' incorporates:
   *  Constant: '<Root>/Constant1'
   *  Gain: '<Root>/deg2rad'
   *  Sum: '<Root>/Sum'
   */
  rtb_Sum2_idx_0 = (helikopter_ex3_P.Constant1_Value +
                    helikopter_ex3_B.VandringLavpass) *
    helikopter_ex3_P.deg2rad_Gain - rtb_FromWorkspace1[0];
  rtb_Sum2_idx_2 = helikopter_ex3_P.deg2rad_Gain *
    helikopter_ex3_B.KalibrerPitch - rtb_FromWorkspace1[2];
  if (rtmIsMajorTimeStep(helikopter_ex3_M)) {
  }

  /* Sum: '<Root>/Sum1' incorporates:
   *  Gain: '<Root>/Gain2'
   *  Gain: '<Root>/deg2rad'
   *  Sum: '<Root>/Sum2'
   */
  rtb_Gain2 -= (((helikopter_ex3_P.deg2rad_Gain * rtb_VandringDeriv -
                  rtb_FromWorkspace1[1]) * helikopter_ex3_P.K[1] +
                 helikopter_ex3_P.K[0] * rtb_Sum2_idx_0) + helikopter_ex3_P.K[2]
                * rtb_Sum2_idx_2) + (helikopter_ex3_P.deg2rad_Gain *
    rtb_TransferFcn4 - rtb_FromWorkspace1[3]) * helikopter_ex3_P.K[3];

  /* Saturate: '<S3>/Saturation' */
  if (rtb_Gain2 > helikopter_ex3_P.Saturation_UpperSat_d) {
    rtb_VandringDeriv = helikopter_ex3_P.Saturation_UpperSat_d;
  } else if (rtb_Gain2 < helikopter_ex3_P.Saturation_LowerSat_n) {
    rtb_VandringDeriv = helikopter_ex3_P.Saturation_LowerSat_n;
  } else {
    rtb_VandringDeriv = rtb_Gain2;
  }

  /* Sum: '<S3>/Sum' incorporates:
   *  Gain: '<S3>/K_pd'
   *  Gain: '<S3>/K_pp'
   *  Saturate: '<S3>/Saturation'
   *  Sum: '<S3>/Sum1'
   */
  rtb_VandringDeriv = 0.3 * helikopter_ex3_P.K_pp * (rtb_VandringDeriv -
    rtb_Gain[2]) - helikopter_ex3_P.K_pd * rtb_Gain[3];

  /* Gain: '<S4>/Gain2' incorporates:
   *  Sum: '<S4>/Sum4'
   */
  rtb_Gain2 = (rtb_Saturation_p - rtb_VandringDeriv) * helikopter_ex3_P.V_b_eq;

  /* Saturate: '<S2>/Sat B' */
  if (rtb_Gain2 > helikopter_ex3_P.SatB_UpperSat) {
    helikopter_ex3_B.SatB = helikopter_ex3_P.SatB_UpperSat;
  } else if (rtb_Gain2 < helikopter_ex3_P.SatB_LowerSat) {
    helikopter_ex3_B.SatB = helikopter_ex3_P.SatB_LowerSat;
  } else {
    helikopter_ex3_B.SatB = rtb_Gain2;
  }

  /* End of Saturate: '<S2>/Sat B' */
  if (rtmIsMajorTimeStep(helikopter_ex3_M)) {
  }

  /* Gain: '<S4>/Gain1' incorporates:
   *  Sum: '<S4>/Sum3'
   */
  rtb_VandringDeriv = (rtb_VandringDeriv + rtb_Saturation_p) *
    helikopter_ex3_P.V_f_eq;

  /* Saturate: '<S2>/Sat' */
  if (rtb_VandringDeriv > helikopter_ex3_P.Sat_UpperSat) {
    helikopter_ex3_B.Sat = helikopter_ex3_P.Sat_UpperSat;
  } else if (rtb_VandringDeriv < helikopter_ex3_P.Sat_LowerSat) {
    helikopter_ex3_B.Sat = helikopter_ex3_P.Sat_LowerSat;
  } else {
    helikopter_ex3_B.Sat = rtb_VandringDeriv;
  }

  /* End of Saturate: '<S2>/Sat' */
  if (rtmIsMajorTimeStep(helikopter_ex3_M)) {
  }

  /* Sum: '<S2>/Add' incorporates:
   *  Constant: '<S2>/elevation'
   */
  helikopter_ex3_B.Add_j = helikopter_ex3_B.SatB -
    helikopter_ex3_P.elevation_Value_g;
  if (rtmIsMajorTimeStep(helikopter_ex3_M)) {
    /* S-Function (hil_write_analog_block): '<S2>/HIL Write Analog' */

    /* S-Function Block: helikopter_ex3/Heli 3D/HIL Write Analog (hil_write_analog_block) */
    {
      t_error result;
      helikopter_ex3_DW.HILWriteAnalog_Buffer[0] = helikopter_ex3_B.Add_j;
      helikopter_ex3_DW.HILWriteAnalog_Buffer[1] = helikopter_ex3_B.Sat;
      result = hil_write_analog(helikopter_ex3_DW.HILInitialize_Card,
        helikopter_ex3_P.HILWriteAnalog_channels, 2,
        &helikopter_ex3_DW.HILWriteAnalog_Buffer[0]);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(helikopter_ex3_M, _rt_error_message);
      }
    }
  }
}

/* Model update function */
void helikopter_ex3_update(void)
{
  if (rtmIsMajorTimeStep(helikopter_ex3_M)) {
    rt_ertODEUpdateContinuousStates(&helikopter_ex3_M->solverInfo);
  }

  /* Update absolute time for base rate */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick0 and the high bits
   * Timing.clockTickH0. When the low bit overflows to 0, the high bits increment.
   */
  if (!(++helikopter_ex3_M->Timing.clockTick0)) {
    ++helikopter_ex3_M->Timing.clockTickH0;
  }

  helikopter_ex3_M->Timing.t[0] = rtsiGetSolverStopTime
    (&helikopter_ex3_M->solverInfo);

  {
    /* Update absolute timer for sample time: [0.002s, 0.0s] */
    /* The "clockTick1" counts the number of times the code of this task has
     * been executed. The absolute time is the multiplication of "clockTick1"
     * and "Timing.stepSize1". Size of "clockTick1" ensures timer will not
     * overflow during the application lifespan selected.
     * Timer of this task consists of two 32 bit unsigned integers.
     * The two integers represent the low bits Timing.clockTick1 and the high bits
     * Timing.clockTickH1. When the low bit overflows to 0, the high bits increment.
     */
    if (!(++helikopter_ex3_M->Timing.clockTick1)) {
      ++helikopter_ex3_M->Timing.clockTickH1;
    }

    helikopter_ex3_M->Timing.t[1] = helikopter_ex3_M->Timing.clockTick1 *
      helikopter_ex3_M->Timing.stepSize1 + helikopter_ex3_M->Timing.clockTickH1 *
      helikopter_ex3_M->Timing.stepSize1 * 4294967296.0;
  }
}

/* Derivatives for root system: '<Root>' */
void helikopter_ex3_derivatives(void)
{
  XDot_helikopter_ex3_T *_rtXdot;
  _rtXdot = ((XDot_helikopter_ex3_T *) helikopter_ex3_M->ModelData.derivs);

  /* Derivatives for TransferFcn: '<S2>/Vandring Lavpass' */
  _rtXdot->VandringLavpass_CSTATE = 0.0;
  _rtXdot->VandringLavpass_CSTATE += helikopter_ex3_P.VandringLavpass_A *
    helikopter_ex3_X.VandringLavpass_CSTATE;
  _rtXdot->VandringLavpass_CSTATE += helikopter_ex3_B.KalibrerVandring;

  /* Derivatives for Integrator: '<S1>/Integrator' */
  {
    boolean_T lsat;
    boolean_T usat;
    lsat = ( helikopter_ex3_X.Integrator_CSTATE <=
            (helikopter_ex3_P.Integrator_LowerSat) );
    usat = ( helikopter_ex3_X.Integrator_CSTATE >=
            helikopter_ex3_P.Integrator_UpperSat );
    if ((!lsat && !usat) ||
        (lsat && (helikopter_ex3_B.K_ei > 0)) ||
        (usat && (helikopter_ex3_B.K_ei < 0)) ) {
      ((XDot_helikopter_ex3_T *) helikopter_ex3_M->ModelData.derivs)
        ->Integrator_CSTATE = helikopter_ex3_B.K_ei;
    } else {
      /* in saturation */
      ((XDot_helikopter_ex3_T *) helikopter_ex3_M->ModelData.derivs)
        ->Integrator_CSTATE = 0.0;
    }
  }

  /* Derivatives for TransferFcn: '<S2>/Vandring Deriv' */
  _rtXdot->VandringDeriv_CSTATE = 0.0;
  _rtXdot->VandringDeriv_CSTATE += helikopter_ex3_P.VandringDeriv_A *
    helikopter_ex3_X.VandringDeriv_CSTATE;
  _rtXdot->VandringDeriv_CSTATE += helikopter_ex3_B.KalibrerVandring;

  /* Derivatives for TransferFcn: '<S2>/Transfer Fcn4' */
  _rtXdot->TransferFcn4_CSTATE = 0.0;
  _rtXdot->TransferFcn4_CSTATE += helikopter_ex3_P.TransferFcn4_A *
    helikopter_ex3_X.TransferFcn4_CSTATE;
  _rtXdot->TransferFcn4_CSTATE += helikopter_ex3_B.KalibrerPitch;

  /* Derivatives for TransferFcn: '<S2>/Transfer Fcn5' */
  _rtXdot->TransferFcn5_CSTATE = 0.0;
  _rtXdot->TransferFcn5_CSTATE += helikopter_ex3_P.TransferFcn5_A *
    helikopter_ex3_X.TransferFcn5_CSTATE;
  _rtXdot->TransferFcn5_CSTATE += helikopter_ex3_B.KalibrerElev;
}

/* Model initialize function */
void helikopter_ex3_initialize(void)
{
  /* Start for S-Function (hil_initialize_block): '<Root>/HIL Initialize' */

  /* S-Function Block: helikopter_ex3/HIL Initialize (hil_initialize_block) */
  {
    t_int result;
    t_boolean is_switching;
    result = hil_open("q8_usb", "0", &helikopter_ex3_DW.HILInitialize_Card);
    if (result < 0) {
      msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
        (_rt_error_message));
      rtmSetErrorStatus(helikopter_ex3_M, _rt_error_message);
      return;
    }

    is_switching = false;
    result = hil_set_card_specific_options(helikopter_ex3_DW.HILInitialize_Card,
      "update_rate=normal;decimation=1", 32);
    if (result < 0) {
      msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
        (_rt_error_message));
      rtmSetErrorStatus(helikopter_ex3_M, _rt_error_message);
      return;
    }

    result = hil_watchdog_clear(helikopter_ex3_DW.HILInitialize_Card);
    if (result < 0 && result != -QERR_HIL_WATCHDOG_CLEAR) {
      msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
        (_rt_error_message));
      rtmSetErrorStatus(helikopter_ex3_M, _rt_error_message);
      return;
    }

    if ((helikopter_ex3_P.HILInitialize_set_analog_input_ && !is_switching) ||
        (helikopter_ex3_P.HILInitialize_set_analog_inpu_m && is_switching)) {
      {
        int_T i1;
        real_T *dw_AIMinimums = &helikopter_ex3_DW.HILInitialize_AIMinimums[0];
        for (i1=0; i1 < 8; i1++) {
          dw_AIMinimums[i1] = helikopter_ex3_P.HILInitialize_analog_input_mini;
        }
      }

      {
        int_T i1;
        real_T *dw_AIMaximums = &helikopter_ex3_DW.HILInitialize_AIMaximums[0];
        for (i1=0; i1 < 8; i1++) {
          dw_AIMaximums[i1] = helikopter_ex3_P.HILInitialize_analog_input_maxi;
        }
      }

      result = hil_set_analog_input_ranges(helikopter_ex3_DW.HILInitialize_Card,
        helikopter_ex3_P.HILInitialize_analog_input_chan, 8U,
        &helikopter_ex3_DW.HILInitialize_AIMinimums[0],
        &helikopter_ex3_DW.HILInitialize_AIMaximums[0]);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(helikopter_ex3_M, _rt_error_message);
        return;
      }
    }

    if ((helikopter_ex3_P.HILInitialize_set_analog_output && !is_switching) ||
        (helikopter_ex3_P.HILInitialize_set_analog_outp_b && is_switching)) {
      {
        int_T i1;
        real_T *dw_AOMinimums = &helikopter_ex3_DW.HILInitialize_AOMinimums[0];
        for (i1=0; i1 < 8; i1++) {
          dw_AOMinimums[i1] = helikopter_ex3_P.HILInitialize_analog_output_min;
        }
      }

      {
        int_T i1;
        real_T *dw_AOMaximums = &helikopter_ex3_DW.HILInitialize_AOMaximums[0];
        for (i1=0; i1 < 8; i1++) {
          dw_AOMaximums[i1] = helikopter_ex3_P.HILInitialize_analog_output_max;
        }
      }

      result = hil_set_analog_output_ranges(helikopter_ex3_DW.HILInitialize_Card,
        helikopter_ex3_P.HILInitialize_analog_output_cha, 8U,
        &helikopter_ex3_DW.HILInitialize_AOMinimums[0],
        &helikopter_ex3_DW.HILInitialize_AOMaximums[0]);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(helikopter_ex3_M, _rt_error_message);
        return;
      }
    }

    if ((helikopter_ex3_P.HILInitialize_set_analog_outp_e && !is_switching) ||
        (helikopter_ex3_P.HILInitialize_set_analog_outp_j && is_switching)) {
      {
        int_T i1;
        real_T *dw_AOVoltages = &helikopter_ex3_DW.HILInitialize_AOVoltages[0];
        for (i1=0; i1 < 8; i1++) {
          dw_AOVoltages[i1] = helikopter_ex3_P.HILInitialize_initial_analog_ou;
        }
      }

      result = hil_write_analog(helikopter_ex3_DW.HILInitialize_Card,
        helikopter_ex3_P.HILInitialize_analog_output_cha, 8U,
        &helikopter_ex3_DW.HILInitialize_AOVoltages[0]);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(helikopter_ex3_M, _rt_error_message);
        return;
      }
    }

    if (helikopter_ex3_P.HILInitialize_set_analog_outp_p) {
      {
        int_T i1;
        real_T *dw_AOVoltages = &helikopter_ex3_DW.HILInitialize_AOVoltages[0];
        for (i1=0; i1 < 8; i1++) {
          dw_AOVoltages[i1] = helikopter_ex3_P.HILInitialize_watchdog_analog_o;
        }
      }

      result = hil_watchdog_set_analog_expiration_state
        (helikopter_ex3_DW.HILInitialize_Card,
         helikopter_ex3_P.HILInitialize_analog_output_cha, 8U,
         &helikopter_ex3_DW.HILInitialize_AOVoltages[0]);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(helikopter_ex3_M, _rt_error_message);
        return;
      }
    }

    if ((helikopter_ex3_P.HILInitialize_set_encoder_param && !is_switching) ||
        (helikopter_ex3_P.HILInitialize_set_encoder_par_m && is_switching)) {
      {
        int_T i1;
        int32_T *dw_QuadratureModes =
          &helikopter_ex3_DW.HILInitialize_QuadratureModes[0];
        for (i1=0; i1 < 8; i1++) {
          dw_QuadratureModes[i1] = helikopter_ex3_P.HILInitialize_quadrature;
        }
      }

      result = hil_set_encoder_quadrature_mode
        (helikopter_ex3_DW.HILInitialize_Card,
         helikopter_ex3_P.HILInitialize_encoder_channels, 8U,
         (t_encoder_quadrature_mode *)
         &helikopter_ex3_DW.HILInitialize_QuadratureModes[0]);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(helikopter_ex3_M, _rt_error_message);
        return;
      }
    }

    if ((helikopter_ex3_P.HILInitialize_set_encoder_count && !is_switching) ||
        (helikopter_ex3_P.HILInitialize_set_encoder_cou_k && is_switching)) {
      {
        int_T i1;
        int32_T *dw_InitialEICounts =
          &helikopter_ex3_DW.HILInitialize_InitialEICounts[0];
        for (i1=0; i1 < 8; i1++) {
          dw_InitialEICounts[i1] =
            helikopter_ex3_P.HILInitialize_initial_encoder_c;
        }
      }

      result = hil_set_encoder_counts(helikopter_ex3_DW.HILInitialize_Card,
        helikopter_ex3_P.HILInitialize_encoder_channels, 8U,
        &helikopter_ex3_DW.HILInitialize_InitialEICounts[0]);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(helikopter_ex3_M, _rt_error_message);
        return;
      }
    }

    if ((helikopter_ex3_P.HILInitialize_set_pwm_params_at && !is_switching) ||
        (helikopter_ex3_P.HILInitialize_set_pwm_params__f && is_switching)) {
      uint32_T num_duty_cycle_modes = 0;
      uint32_T num_frequency_modes = 0;

      {
        int_T i1;
        int32_T *dw_POModeValues =
          &helikopter_ex3_DW.HILInitialize_POModeValues[0];
        for (i1=0; i1 < 8; i1++) {
          dw_POModeValues[i1] = helikopter_ex3_P.HILInitialize_pwm_modes;
        }
      }

      result = hil_set_pwm_mode(helikopter_ex3_DW.HILInitialize_Card,
        helikopter_ex3_P.HILInitialize_pwm_channels, 8U, (t_pwm_mode *)
        &helikopter_ex3_DW.HILInitialize_POModeValues[0]);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(helikopter_ex3_M, _rt_error_message);
        return;
      }

      {
        int_T i1;
        const uint32_T *p_HILInitialize_pwm_channels =
          helikopter_ex3_P.HILInitialize_pwm_channels;
        int32_T *dw_POModeValues =
          &helikopter_ex3_DW.HILInitialize_POModeValues[0];
        for (i1=0; i1 < 8; i1++) {
          if (dw_POModeValues[i1] == PWM_DUTY_CYCLE_MODE || dw_POModeValues[i1] ==
              PWM_ONE_SHOT_MODE || dw_POModeValues[i1] == PWM_TIME_MODE) {
            helikopter_ex3_DW.HILInitialize_POSortedChans[num_duty_cycle_modes] =
              p_HILInitialize_pwm_channels[i1];
            helikopter_ex3_DW.HILInitialize_POSortedFreqs[num_duty_cycle_modes] =
              helikopter_ex3_P.HILInitialize_pwm_frequency;
            num_duty_cycle_modes++;
          } else {
            helikopter_ex3_DW.HILInitialize_POSortedChans[7U -
              num_frequency_modes] = p_HILInitialize_pwm_channels[i1];
            helikopter_ex3_DW.HILInitialize_POSortedFreqs[7U -
              num_frequency_modes] =
              helikopter_ex3_P.HILInitialize_pwm_frequency;
            num_frequency_modes++;
          }
        }
      }

      if (num_duty_cycle_modes > 0) {
        result = hil_set_pwm_frequency(helikopter_ex3_DW.HILInitialize_Card,
          &helikopter_ex3_DW.HILInitialize_POSortedChans[0],
          num_duty_cycle_modes, &helikopter_ex3_DW.HILInitialize_POSortedFreqs[0]);
        if (result < 0) {
          msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
            (_rt_error_message));
          rtmSetErrorStatus(helikopter_ex3_M, _rt_error_message);
          return;
        }
      }

      if (num_frequency_modes > 0) {
        result = hil_set_pwm_duty_cycle(helikopter_ex3_DW.HILInitialize_Card,
          &helikopter_ex3_DW.HILInitialize_POSortedChans[num_duty_cycle_modes],
          num_frequency_modes,
          &helikopter_ex3_DW.HILInitialize_POSortedFreqs[num_duty_cycle_modes]);
        if (result < 0) {
          msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
            (_rt_error_message));
          rtmSetErrorStatus(helikopter_ex3_M, _rt_error_message);
          return;
        }
      }

      {
        int_T i1;
        int32_T *dw_POModeValues =
          &helikopter_ex3_DW.HILInitialize_POModeValues[0];
        for (i1=0; i1 < 8; i1++) {
          dw_POModeValues[i1] = helikopter_ex3_P.HILInitialize_pwm_configuration;
        }
      }

      {
        int_T i1;
        int32_T *dw_POAlignValues =
          &helikopter_ex3_DW.HILInitialize_POAlignValues[0];
        for (i1=0; i1 < 8; i1++) {
          dw_POAlignValues[i1] = helikopter_ex3_P.HILInitialize_pwm_alignment;
        }
      }

      {
        int_T i1;
        int32_T *dw_POPolarityVals =
          &helikopter_ex3_DW.HILInitialize_POPolarityVals[0];
        for (i1=0; i1 < 8; i1++) {
          dw_POPolarityVals[i1] = helikopter_ex3_P.HILInitialize_pwm_polarity;
        }
      }

      result = hil_set_pwm_configuration(helikopter_ex3_DW.HILInitialize_Card,
        helikopter_ex3_P.HILInitialize_pwm_channels, 8U,
        (t_pwm_configuration *) &helikopter_ex3_DW.HILInitialize_POModeValues[0],
        (t_pwm_alignment *) &helikopter_ex3_DW.HILInitialize_POAlignValues[0],
        (t_pwm_polarity *) &helikopter_ex3_DW.HILInitialize_POPolarityVals[0]);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(helikopter_ex3_M, _rt_error_message);
        return;
      }

      {
        int_T i1;
        real_T *dw_POSortedFreqs =
          &helikopter_ex3_DW.HILInitialize_POSortedFreqs[0];
        for (i1=0; i1 < 8; i1++) {
          dw_POSortedFreqs[i1] =
            helikopter_ex3_P.HILInitialize_pwm_leading_deadb;
        }
      }

      {
        int_T i1;
        real_T *dw_POValues = &helikopter_ex3_DW.HILInitialize_POValues[0];
        for (i1=0; i1 < 8; i1++) {
          dw_POValues[i1] = helikopter_ex3_P.HILInitialize_pwm_trailing_dead;
        }
      }

      result = hil_set_pwm_deadband(helikopter_ex3_DW.HILInitialize_Card,
        helikopter_ex3_P.HILInitialize_pwm_channels, 8U,
        &helikopter_ex3_DW.HILInitialize_POSortedFreqs[0],
        &helikopter_ex3_DW.HILInitialize_POValues[0]);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(helikopter_ex3_M, _rt_error_message);
        return;
      }
    }

    if ((helikopter_ex3_P.HILInitialize_set_pwm_outputs_a && !is_switching) ||
        (helikopter_ex3_P.HILInitialize_set_pwm_outputs_g && is_switching)) {
      {
        int_T i1;
        real_T *dw_POValues = &helikopter_ex3_DW.HILInitialize_POValues[0];
        for (i1=0; i1 < 8; i1++) {
          dw_POValues[i1] = helikopter_ex3_P.HILInitialize_initial_pwm_outpu;
        }
      }

      result = hil_write_pwm(helikopter_ex3_DW.HILInitialize_Card,
        helikopter_ex3_P.HILInitialize_pwm_channels, 8U,
        &helikopter_ex3_DW.HILInitialize_POValues[0]);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(helikopter_ex3_M, _rt_error_message);
        return;
      }
    }

    if (helikopter_ex3_P.HILInitialize_set_pwm_outputs_o) {
      {
        int_T i1;
        real_T *dw_POValues = &helikopter_ex3_DW.HILInitialize_POValues[0];
        for (i1=0; i1 < 8; i1++) {
          dw_POValues[i1] = helikopter_ex3_P.HILInitialize_watchdog_pwm_outp;
        }
      }

      result = hil_watchdog_set_pwm_expiration_state
        (helikopter_ex3_DW.HILInitialize_Card,
         helikopter_ex3_P.HILInitialize_pwm_channels, 8U,
         &helikopter_ex3_DW.HILInitialize_POValues[0]);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(helikopter_ex3_M, _rt_error_message);
        return;
      }
    }
  }

  /* Start for ToFile: '<Root>/To File' */
  {
    char fileName[509] = "PitchDataE1.mat";
    FILE *fp = (NULL);
    if ((fp = fopen(fileName, "wb")) == (NULL)) {
      rtmSetErrorStatus(helikopter_ex3_M,
                        "Error creating .mat file PitchDataE1.mat");
      return;
    }

    if (rt_WriteMat4FileHeader(fp,2,0,"PitchDataE1")) {
      rtmSetErrorStatus(helikopter_ex3_M,
                        "Error writing mat file header to file PitchDataE1.mat");
      return;
    }

    helikopter_ex3_DW.ToFile_IWORK.Count = 0;
    helikopter_ex3_DW.ToFile_IWORK.Decimation = -1;
    helikopter_ex3_DW.ToFile_PWORK.FilePtr = fp;
  }

  /* Start for FromWorkspace: '<Root>/From Workspace' */
  {
    static real_T pTimeValues0[] = { 0.0, 0.25, 0.5, 0.75, 1.0, 1.25, 1.5, 1.75,
      2.0, 2.25, 2.5, 2.75, 3.0, 3.25, 3.5, 3.75, 4.0, 4.25, 4.5, 4.75, 5.0,
      5.25, 5.5, 5.75, 6.0, 6.25, 6.5, 6.75, 7.0, 7.25, 7.5, 7.75, 8.0, 8.25,
      8.5, 8.75, 9.0, 9.25, 9.5, 9.75, 10.0, 10.25, 10.5, 10.75, 11.0, 11.25,
      11.5, 11.75, 12.0, 12.25, 12.5, 12.75, 13.0, 13.25, 13.5, 13.75, 14.0,
      14.25, 14.5, 14.75, 15.0, 15.25, 15.5, 15.75, 16.0, 16.25, 16.5, 16.75,
      17.0, 17.25, 17.5, 17.75, 18.0, 18.25, 18.5, 18.75, 19.0, 19.25, 19.5,
      19.75, 20.0, 20.25, 20.5, 20.75, 21.0, 21.25, 21.5, 21.75, 22.0, 22.25,
      22.5, 22.75, 23.0, 23.25, 23.5, 23.75, 24.0, 24.25, 24.5, 24.75, 25.0,
      25.25, 25.5, 25.75, 26.0, 26.25, 26.5, 26.75, 27.0, 27.25, 27.5, 27.75,
      28.0, 28.25, 28.5, 28.75, 29.0, 29.25, 29.5, 29.75, 30.0, 30.25, 30.5,
      30.75, 31.0, 31.25, 31.5, 31.75, 32.0, 32.25, 32.5, 32.75, 33.0, 33.25,
      33.5, 33.75, 34.0, 34.25, 34.5, 34.75, 35.0 } ;

    static real_T pDataValues0[] = { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
      0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.236953756542594,
      0.059238439157873218, 0.523598775165739, 0.523598775224195,
      0.52359877506637231, 0.5235987749567298, 0.52359877488109086,
      0.52359877478780481, 0.52359877466175009, 0.5235987745063535,
      0.52359877431029334, 0.52359877404001776, 0.52359877362905449,
      0.5235987729960635, 0.523598772144358, 0.52359877088743656,
      0.52359876650944981, 0.523598188295265, 0.43189208664609685,
      0.37447831012189936, 0.2098033621371323, -0.0099595324120339869,
      -0.1682925996569152, -0.24949764554696982, -0.309263801894483,
      -0.3791070950265899, -0.44480362594695011, -0.48687875594760283,
      -0.507087937518374, -0.5176793738215042, -0.52211548687898579,
      -0.52023759800551328, -0.51412099787697274, -0.50314125120119169,
      -0.48475910089312935, -0.46126044052456938, -0.43600870694116944,
      -0.41003025804339455, -0.38279271428826322, -0.35425984244110731,
      -0.32528799712700013, -0.29673594522675345, -0.26892869563994753,
      -0.24191324909596248, -0.21583662411553239, -0.19096643746945752,
      -0.16751211029790661, -0.14555190321527559, -0.12510186402553514,
      -0.10618474215262977, -0.088826131197716082, -0.073022424549939777,
      -0.058734752276790814, -0.045906877069841451, -0.034478642956004446,
      -0.024385149823832674, -0.015552400539615008, -0.0078985617167943584,
      -0.0013388692789422622, 0.004211220226514662, 0.0088356745809401744,
      0.012617951389035197, 0.015640023469822312, 0.017980997487179393,
      0.019716294163116578, 0.020917419226315993, 0.021651824379731059,
      0.021982633691206774, 0.021968387493762849, 0.021662962295842976,
      0.021115638656142129, 0.02037121276409562, 0.019470108382333536,
      0.018448509604698269, 0.017338541777283504, 0.016168507360514867,
      0.014963154795294446, 0.013743928806368939, 0.01252916807007665,
      0.011334307683357093, 0.010172196268976533, 0.0090534957490457733,
      0.0079869144877342535, 0.0069791386150946213, 0.0060348430920987408,
      0.0051573315472718635, 0.0043494665123419872, 0.0036135570480122919,
      0.0029498646807609836, 0.0023560847064387136, 0.0018302345548466517,
      0.0013741529275187393, 0.00099074689632501229, 0.0006753212883723065,
      0.000414692100416423, 0.00020370339228372087, 5.9508736956499474E-5,
      4.2819313073238815E-8, -1.7733488916783239E-8, 0.0, 0.0, 0.0, 0.0, 0.0,
      0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
      0.0, 0.0 } ;

    helikopter_ex3_DW.FromWorkspace_PWORK.TimePtr = (void *) pTimeValues0;
    helikopter_ex3_DW.FromWorkspace_PWORK.DataPtr = (void *) pDataValues0;
    helikopter_ex3_DW.FromWorkspace_IWORK.PrevIndex = 0;
  }

  /* Start for FromWorkspace: '<Root>/From Workspace1' */
  {
    static real_T pTimeValues0[] = { 0.0, 0.25, 0.5, 0.75, 1.0, 1.25, 1.5, 1.75,
      2.0, 2.25, 2.5, 2.75, 3.0, 3.25, 3.5, 3.75, 4.0, 4.25, 4.5, 4.75, 5.0,
      5.25, 5.5, 5.75, 6.0, 6.25, 6.5, 6.75, 7.0, 7.25, 7.5, 7.75, 8.0, 8.25,
      8.5, 8.75, 9.0, 9.25, 9.5, 9.75, 10.0, 10.25, 10.5, 10.75, 11.0, 11.25,
      11.5, 11.75, 12.0, 12.25, 12.5, 12.75, 13.0, 13.25, 13.5, 13.75, 14.0,
      14.25, 14.5, 14.75, 15.0, 15.25, 15.5, 15.75, 16.0, 16.25, 16.5, 16.75,
      17.0, 17.25, 17.5, 17.75, 18.0, 18.25, 18.5, 18.75, 19.0, 19.25, 19.5,
      19.75, 20.0, 20.25, 20.5, 20.75, 21.0, 21.25, 21.5, 21.75, 22.0, 22.25,
      22.5, 22.75, 23.0, 23.25, 23.5, 23.75, 24.0, 24.25, 24.5, 24.75, 25.0,
      25.25, 25.5, 25.75, 26.0, 26.25, 26.5, 26.75, 27.0, 27.25, 27.5, 27.75,
      28.0, 28.25, 28.5, 28.75, 29.0, 29.25, 29.5, 29.75, 30.0, 30.25, 30.5,
      30.75, 31.0, 31.25, 31.5, 31.75, 32.0, 32.25, 32.5, 32.75, 33.0, 33.25,
      33.5, 33.75, 34.0, 34.25, 34.5, 34.75, 35.0 } ;

    static real_T pDataValues0[] = { 3.1415926535897931, 3.1415926535897931,
      3.1415926535897931, 3.1415926535897931, 3.1415926535897931,
      3.1415926535897931, 3.1415926535897931, 3.1415926535897931,
      3.1415926535897931, 3.1415926535897931, 3.1415926535897931,
      3.1415926535897931, 3.1415926535897931, 3.1415926535897931,
      3.1415926535897931, 3.1415926535897931, 3.1415926535897931,
      3.1415926535897931, 3.1415926535897931, 3.1415926535897931,
      3.1415926535897931, 3.1415926535897931, 3.1415926535897931,
      3.1415926535897931, 3.1340811534453494, 3.1190581532385324,
      3.0965236529306597, 3.0664776525232309, 3.0289201520170974,
      2.9838511514134334, 2.9312706507138491, 2.8711786499202092,
      2.803575149034752, 2.7284601480604271, 2.6458336470012771,
      2.5556956458631204, 2.4580461446554267, 2.3528851433939608,
      2.2402126420989896, 2.1200286407946618, 1.9923331395981558,
      1.8571261568795823, 1.7173148151605697, 1.5768994530448746,
      1.4384034529465708, 1.3028463983348022, 1.1710670847101767,
      1.0442707446925426, 0.923612111722524, 0.8098093828927615,
      0.70322086319783639, 0.60404161764334519, 0.51235640825803175,
      0.42818228745845954, 0.351506561692562, 0.28222676342683145,
      0.22009701974714638, 0.16478567145506773, 0.11594309415205273,
      0.073212110871950342, 0.036209513872329319, 0.0045243360829862432,
      -0.022264109981386958, -0.044570464182954628, -0.062799697065770932,
      -0.077348071196759891, -0.088600656765881677, -0.0969260944017665,
      -0.10267287545531678, -0.10616833204193002, -0.10771853042522658,
      -0.10760768939459787, -0.1060974442653453, -0.10342671352628112,
      -0.099812229846465483, -0.095449313992684179, -0.090512646836729549,
      -0.08515711444640009, -0.07951883595547983, -0.073716335685661313,
      -0.067851753642012083, -0.062012050508209147, -0.056270226219318674,
      -0.050686552502749047, -0.045309771038363124, -0.040178222286666593,
      -0.035320942626366279, -0.030758782736413175, -0.026505487170427833,
      -0.022568579086031965, -0.018950046378240114, -0.015647123518281372,
      -0.012653389056012033, -0.0099597644707200214, -0.0075546747316527288,
      -0.0054236313134966218, -0.0035498862506634257, -0.0019168868920499882,
      -0.00050985359366103255, 0.00068695042028025285, 0.0016945739469720724,
      0.00253661389160467, 0.0032280266760623391, 0.00377166396374563,
      0.0041771935278754387, 0.0044817408869941662, 0.0047280150839603425,
      0.004907239475516652, 0.0049590687279182271, 0.0048832608653930788,
      0.0048235032278227024, 0.0049113640572020032, 0.0049849734392064735,
      0.0046839165013949765, 0.00407176956370275, 0.0039169809387057273,
      0.0046834498721182267, 0.0052231650409836792, 0.0037742725872889076,
      0.0012718382855612181, 0.0018744527956325741, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
      0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
      0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
      0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, -0.030046000392953198,
      -0.060092000807948229, -0.090138001212171665, -0.12018400161039448,
      -0.150230002005214, -0.18027600239533761, -0.2103220027790178,
      -0.2403680031552391, -0.27041400352250972, -0.30046000387798005,
      -0.33050600421728021, -0.36055200453330666, -0.390598004811456,
      -0.42064400502654326, -0.45069000516056495, -0.48073600519799164,
      -0.51078200476670332, -0.54082793085497394, -0.55924536685673021,
      -0.56166144844346111, -0.553984000373895, -0.54222821842775415,
      -0.52711725447918256, -0.50718536005121739, -0.48263453186075406,
      -0.45521091529973, -0.42635407876038056, -0.39671698219864482,
      -0.36674083752193409, -0.33669648317896872, -0.30670290304427028,
      -0.27711919304360205, -0.24851897469942039, -0.22124539314899477,
      -0.19537030919274004, -0.17092393310108964, -0.14801038797916416,
      -0.12674071113805238, -0.10715378423817289, -0.089225416786950756,
      -0.072916931511945254, -0.058193496504635935, -0.045010342257167248,
      -0.033301750524219347, -0.022987124194881213, -0.013981826327133018,
      -0.0062007935138663622, 0.00044336414183477718, 0.0060409805363301934,
      0.010682922975576688, 0.014457934738582446, 0.017451663434445104,
      0.019746668643138472, 0.021422129580637727, 0.022553113983000968,
      0.023210001098593988, 0.023458328193916873, 0.023358812554531656,
      0.022967297174881808, 0.022334694885598423, 0.021507125876863604,
      0.020526195026106059, 0.019429118660521178, 0.018248639579132326,
      0.017013182283261291, 0.0157476323569034, 0.014474130850487307,
      0.0132116914591549, 0.011974937868397284, 0.010774498360487966,
      0.00962035897558909, 0.0085241736919443485, 0.0074949802706527034,
      0.0065319974537736709, 0.0056281332128757426, 0.0047872160750850618,
      0.0040304941260871988, 0.0033681597978503105, 0.0027656511571505977,
      0.0021745491700530853, 0.0016221182758391552, 0.0012181894557948285,
      0.00098509680718462489, 0.00071689758554515748, 0.00020731702892622263,
      -0.00030323143078067637, -0.00023903053096158437, 0.00035144333683712243,
      0.00029443754733780262, -0.0012042277319260681, -0.0024485877314489859,
      -0.00061915448066817, 0.0030658757529699169, 0.0021588606947817303,
      -0.0057955697954591686, -0.010009737187590836, 0.0024104580596053444,
      0.019984139530101704, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
      0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
      0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
      0.0, 0.0, 0.5235987752453215, 0.52359877529275523, 0.52359877510504294,
      0.523598775000473, 0.52359877494116491, 0.52359877485933215,
      0.52359877474704419, 0.52359877461706172, 0.52359877446108227,
      0.5235987742554441, 0.52359877397365384, 0.52359877356807194,
      0.52359877290800338, 0.52359877180904857, 0.5235987703963535,
      0.52359876871303312, 0.52359876054493837, 0.52359748003277562,
      0.32095276580477211, 0.04210401858399293, -0.13379159791777787,
      -0.20486297492340474, -0.2633322940703508, -0.34734458388971062,
      -0.42783676347414196, -0.47789961549178595, -0.50287572595606933,
      -0.516472983044794, -0.522381429271044, -0.523570089898771,
      -0.52268526952674765, -0.51554263831984182, -0.49840375062319442,
      -0.47528501964824083, -0.45091400129496617, -0.42601652150317437,
      -0.39930453297252488, -0.37065754479817153, -0.341332982587497,
      -0.31242997772591963, -0.28420098511894865, -0.2565789932571837,
      -0.22973718042623223, -0.20404061129788731, -0.17974857348759435,
      -0.15693146740112265, -0.1355967248628413, -0.11578488861378657,
      -0.097547262470836782, -0.080893141934486684, -0.065785512497193846,
      -0.052170427245842171, -0.039994072420032133, -0.029197539864758683,
      -0.019709180581170573, -0.011447290303150762, -0.0043274898873905928,
      0.0017342164086792517, 0.0068227707678732916, 0.011024089042500986,
      0.014421690524143604, 0.017094261633458705, 0.019118279754981173,
      0.020571703147372864, 0.021529784934399328, 0.022054196311973685,
      0.022192765090599819, 0.021999990350869025, 0.021552374909958708,
      0.020919544947814311, 0.020112692542526307, 0.01910275125181608,
      0.017935312770883095, 0.016781488937329905, 0.015751254844500382,
      0.01465430264986921, 0.013187069170255227, 0.011542216545927776,
      0.010499659922989757, 0.010300881058122657, 0.0096269764920116924,
      0.0070390944747871134, 0.0040620057141214569, 0.0046737929200365231,
      0.0088802420190140837, 0.0088971092514063925, -0.0011188015716971705,
      -0.010289935090212197, 0.000993415469097867, 0.026116597683117807,
      0.021684928536360608, -0.031880749395130185, -0.064217442939680375,
      0.015806162787373342, 0.13861845188503841, 0.0734384894810733,
      -0.21644142083684173, -0.30624901711466684, 0.19447533152951396, 0.0, 0.0,
      0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
      0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
      0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 2.0943951009965596,
      2.0905448057365794E-10, -7.315291642101895E-10, -3.9895974486185054E-10,
      -2.1791300819435498E-10, -3.0801106215526481E-10, -4.298315704246275E-10,
      -5.0060963872346473E-10, -6.0459777116768864E-10, -8.0323301116262913E-10,
      -1.1078410855533432E-9, -1.6030079128302318E-9, -2.6209541664824193E-9,
      -4.37649919254734E-9, -5.6314605669435637E-9, -6.7139617591863734E-9,
      -3.2653058992461404E-8, -5.1220293312620653E-6, -0.81057885689269416,
      -1.1153949888637968, -0.70358246598776319, -0.28428550800318764,
      -0.23387727656846435, -0.33604915925811951, -0.32196871831840534,
      -0.20025140805125616, -0.099904441837813551, -0.054389028335578793,
      -0.023633784885680041, -0.0047546424915881069, 0.0035392815074131688,
      0.028570524846943252, 0.068555550805909665, 0.092474923919134089,
      0.097484073432418647, 0.09958991918648713, 0.10684795414191783,
      0.11458795271673322, 0.11729824886201813, 0.11561201946562946,
      0.11291597044720386, 0.11048796746637987, 0.10736725134312572,
      0.10278627653269967, 0.097168151260491678, 0.091268424365206685,
      0.08533897017244528, 0.079247345015538859, 0.072950504591119028,
      0.066616482164720325, 0.060430517768491267, 0.054460341024726647,
      0.048705419322560076, 0.043186130240413727, 0.037953437153672352,
      0.033047561131399172, 0.028479201682360594, 0.0242468252035993,
      0.020354217456096082, 0.016805273117830703, 0.013590405945890387,
      0.010690284456580329, 0.0080960725054097862, 0.0058136935888866981,
      0.0038323271674257763, 0.0020976455296173322, 0.00055427513382446075,
      -0.00077109893960324635, -0.0017904617443213488, -0.0025313198292576666,
      -0.0032274096018320973, -0.0040397651435209866, -0.0046697539044120188,
      -0.0046152953148928316, -0.0041209363519981645, -0.0043878087592047737,
      -0.0058689338991360076, -0.006579410477989882, -0.0041702264724321567,
      -0.00079511544014848254, -0.0026956182451239345, -0.010351528049578397,
      -0.011908355023342703, 0.0024471488429801845, 0.01682579641523016,
      6.7468948889158327E-5, -0.040063643273094335, -0.036684534054740189,
      0.045133402256560179, 0.10049272887539967, -0.017726676567708863,
      -0.21426271170664327, -0.1293467741588808, 0.32009442292753476,
      0.49124915640998013, -0.26071984959654054, -1.1595196412523403,
      -0.35923038509198041, 2.0028973945960429, 2.2061601105196891, 0.0, 0.0,
      0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
      0.0, 0.0, 0.0 } ;

    helikopter_ex3_DW.FromWorkspace1_PWORK.TimePtr = (void *) pTimeValues0;
    helikopter_ex3_DW.FromWorkspace1_PWORK.DataPtr = (void *) pDataValues0;
    helikopter_ex3_DW.FromWorkspace1_IWORK.PrevIndex = 0;
  }

  /* InitializeConditions for TransferFcn: '<S2>/Vandring Lavpass' */
  helikopter_ex3_X.VandringLavpass_CSTATE = 0.0;

  /* InitializeConditions for Integrator: '<S1>/Integrator' */
  helikopter_ex3_X.Integrator_CSTATE = helikopter_ex3_P.Integrator_IC;

  /* InitializeConditions for TransferFcn: '<S2>/Vandring Deriv' */
  helikopter_ex3_X.VandringDeriv_CSTATE = 0.0;

  /* InitializeConditions for TransferFcn: '<S2>/Transfer Fcn4' */
  helikopter_ex3_X.TransferFcn4_CSTATE = 0.0;

  /* InitializeConditions for TransferFcn: '<S2>/Transfer Fcn5' */
  helikopter_ex3_X.TransferFcn5_CSTATE = 0.0;
}

/* Model terminate function */
void helikopter_ex3_terminate(void)
{
  /* Terminate for S-Function (hil_initialize_block): '<Root>/HIL Initialize' */

  /* S-Function Block: helikopter_ex3/HIL Initialize (hil_initialize_block) */
  {
    t_boolean is_switching;
    t_int result;
    t_uint32 num_final_analog_outputs = 0;
    t_uint32 num_final_pwm_outputs = 0;
    hil_task_stop_all(helikopter_ex3_DW.HILInitialize_Card);
    hil_monitor_stop_all(helikopter_ex3_DW.HILInitialize_Card);
    is_switching = false;
    if ((helikopter_ex3_P.HILInitialize_set_analog_out_ex && !is_switching) ||
        (helikopter_ex3_P.HILInitialize_set_analog_outp_c && is_switching)) {
      {
        int_T i1;
        real_T *dw_AOVoltages = &helikopter_ex3_DW.HILInitialize_AOVoltages[0];
        for (i1=0; i1 < 8; i1++) {
          dw_AOVoltages[i1] = helikopter_ex3_P.HILInitialize_final_analog_outp;
        }
      }

      num_final_analog_outputs = 8U;
    }

    if ((helikopter_ex3_P.HILInitialize_set_pwm_output_ap && !is_switching) ||
        (helikopter_ex3_P.HILInitialize_set_pwm_outputs_p && is_switching)) {
      {
        int_T i1;
        real_T *dw_POValues = &helikopter_ex3_DW.HILInitialize_POValues[0];
        for (i1=0; i1 < 8; i1++) {
          dw_POValues[i1] = helikopter_ex3_P.HILInitialize_final_pwm_outputs;
        }
      }

      num_final_pwm_outputs = 8U;
    }

    if (0
        || num_final_analog_outputs > 0
        || num_final_pwm_outputs > 0
        ) {
      /* Attempt to write the final outputs atomically (due to firmware issue in old Q2-USB). Otherwise write channels individually */
      result = hil_write(helikopter_ex3_DW.HILInitialize_Card
                         , helikopter_ex3_P.HILInitialize_analog_output_cha,
                         num_final_analog_outputs
                         , helikopter_ex3_P.HILInitialize_pwm_channels,
                         num_final_pwm_outputs
                         , NULL, 0
                         , NULL, 0
                         , &helikopter_ex3_DW.HILInitialize_AOVoltages[0]
                         , &helikopter_ex3_DW.HILInitialize_POValues[0]
                         , (t_boolean *) NULL
                         , NULL
                         );
      if (result == -QERR_HIL_WRITE_NOT_SUPPORTED) {
        t_error local_result;
        result = 0;

        /* The hil_write operation is not supported by this card. Write final outputs for each channel type */
        if (num_final_analog_outputs > 0) {
          local_result = hil_write_analog(helikopter_ex3_DW.HILInitialize_Card,
            helikopter_ex3_P.HILInitialize_analog_output_cha,
            num_final_analog_outputs,
            &helikopter_ex3_DW.HILInitialize_AOVoltages[0]);
          if (local_result < 0) {
            result = local_result;
          }
        }

        if (num_final_pwm_outputs > 0) {
          local_result = hil_write_pwm(helikopter_ex3_DW.HILInitialize_Card,
            helikopter_ex3_P.HILInitialize_pwm_channels, num_final_pwm_outputs,
            &helikopter_ex3_DW.HILInitialize_POValues[0]);
          if (local_result < 0) {
            result = local_result;
          }
        }

        if (result < 0) {
          msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
            (_rt_error_message));
          rtmSetErrorStatus(helikopter_ex3_M, _rt_error_message);
        }
      }
    }

    hil_task_delete_all(helikopter_ex3_DW.HILInitialize_Card);
    hil_monitor_delete_all(helikopter_ex3_DW.HILInitialize_Card);
    hil_close(helikopter_ex3_DW.HILInitialize_Card);
    helikopter_ex3_DW.HILInitialize_Card = NULL;
  }

  /* Terminate for ToFile: '<Root>/To File' */
  {
    FILE *fp = (FILE *) helikopter_ex3_DW.ToFile_PWORK.FilePtr;
    if (fp != (NULL)) {
      char fileName[509] = "PitchDataE1.mat";
      if (fclose(fp) == EOF) {
        rtmSetErrorStatus(helikopter_ex3_M,
                          "Error closing MAT-file PitchDataE1.mat");
        return;
      }

      if ((fp = fopen(fileName, "r+b")) == (NULL)) {
        rtmSetErrorStatus(helikopter_ex3_M,
                          "Error reopening MAT-file PitchDataE1.mat");
        return;
      }

      if (rt_WriteMat4FileHeader(fp, 2, helikopter_ex3_DW.ToFile_IWORK.Count,
           "PitchDataE1")) {
        rtmSetErrorStatus(helikopter_ex3_M,
                          "Error writing header for PitchDataE1 to MAT-file PitchDataE1.mat");
      }

      if (fclose(fp) == EOF) {
        rtmSetErrorStatus(helikopter_ex3_M,
                          "Error closing MAT-file PitchDataE1.mat");
        return;
      }

      helikopter_ex3_DW.ToFile_PWORK.FilePtr = (NULL);
    }
  }
}

/*========================================================================*
 * Start of Classic call interface                                        *
 *========================================================================*/

/* Solver interface called by GRT_Main */
#ifndef USE_GENERATED_SOLVER

void rt_ODECreateIntegrationData(RTWSolverInfo *si)
{
  UNUSED_PARAMETER(si);
  return;
}                                      /* do nothing */

void rt_ODEDestroyIntegrationData(RTWSolverInfo *si)
{
  UNUSED_PARAMETER(si);
  return;
}                                      /* do nothing */

void rt_ODEUpdateContinuousStates(RTWSolverInfo *si)
{
  UNUSED_PARAMETER(si);
  return;
}                                      /* do nothing */

#endif

void MdlOutputs(int_T tid)
{
  helikopter_ex3_output();
  UNUSED_PARAMETER(tid);
}

void MdlUpdate(int_T tid)
{
  helikopter_ex3_update();
  UNUSED_PARAMETER(tid);
}

void MdlInitializeSizes(void)
{
}

void MdlInitializeSampleTimes(void)
{
}

void MdlInitialize(void)
{
}

void MdlStart(void)
{
  helikopter_ex3_initialize();
}

void MdlTerminate(void)
{
  helikopter_ex3_terminate();
}

/* Registration function */
RT_MODEL_helikopter_ex3_T *helikopter_ex3(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* non-finite (run-time) assignments */
  helikopter_ex3_P.Integrator_UpperSat = rtInf;
  helikopter_ex3_P.Integrator_LowerSat = rtMinusInf;

  /* initialize real-time model */
  (void) memset((void *)helikopter_ex3_M, 0,
                sizeof(RT_MODEL_helikopter_ex3_T));

  {
    /* Setup solver object */
    rtsiSetSimTimeStepPtr(&helikopter_ex3_M->solverInfo,
                          &helikopter_ex3_M->Timing.simTimeStep);
    rtsiSetTPtr(&helikopter_ex3_M->solverInfo, &rtmGetTPtr(helikopter_ex3_M));
    rtsiSetStepSizePtr(&helikopter_ex3_M->solverInfo,
                       &helikopter_ex3_M->Timing.stepSize0);
    rtsiSetdXPtr(&helikopter_ex3_M->solverInfo,
                 &helikopter_ex3_M->ModelData.derivs);
    rtsiSetContStatesPtr(&helikopter_ex3_M->solverInfo, (real_T **)
                         &helikopter_ex3_M->ModelData.contStates);
    rtsiSetNumContStatesPtr(&helikopter_ex3_M->solverInfo,
      &helikopter_ex3_M->Sizes.numContStates);
    rtsiSetErrorStatusPtr(&helikopter_ex3_M->solverInfo, (&rtmGetErrorStatus
      (helikopter_ex3_M)));
    rtsiSetRTModelPtr(&helikopter_ex3_M->solverInfo, helikopter_ex3_M);
  }

  rtsiSetSimTimeStep(&helikopter_ex3_M->solverInfo, MAJOR_TIME_STEP);
  helikopter_ex3_M->ModelData.intgData.f[0] = helikopter_ex3_M->ModelData.odeF[0];
  helikopter_ex3_M->ModelData.contStates = ((real_T *) &helikopter_ex3_X);
  rtsiSetSolverData(&helikopter_ex3_M->solverInfo, (void *)
                    &helikopter_ex3_M->ModelData.intgData);
  rtsiSetSolverName(&helikopter_ex3_M->solverInfo,"ode1");

  /* Initialize timing info */
  {
    int_T *mdlTsMap = helikopter_ex3_M->Timing.sampleTimeTaskIDArray;
    mdlTsMap[0] = 0;
    mdlTsMap[1] = 1;
    helikopter_ex3_M->Timing.sampleTimeTaskIDPtr = (&mdlTsMap[0]);
    helikopter_ex3_M->Timing.sampleTimes =
      (&helikopter_ex3_M->Timing.sampleTimesArray[0]);
    helikopter_ex3_M->Timing.offsetTimes =
      (&helikopter_ex3_M->Timing.offsetTimesArray[0]);

    /* task periods */
    helikopter_ex3_M->Timing.sampleTimes[0] = (0.0);
    helikopter_ex3_M->Timing.sampleTimes[1] = (0.002);

    /* task offsets */
    helikopter_ex3_M->Timing.offsetTimes[0] = (0.0);
    helikopter_ex3_M->Timing.offsetTimes[1] = (0.0);
  }

  rtmSetTPtr(helikopter_ex3_M, &helikopter_ex3_M->Timing.tArray[0]);

  {
    int_T *mdlSampleHits = helikopter_ex3_M->Timing.sampleHitArray;
    mdlSampleHits[0] = 1;
    mdlSampleHits[1] = 1;
    helikopter_ex3_M->Timing.sampleHits = (&mdlSampleHits[0]);
  }

  rtmSetTFinal(helikopter_ex3_M, -1);
  helikopter_ex3_M->Timing.stepSize0 = 0.002;
  helikopter_ex3_M->Timing.stepSize1 = 0.002;

  /* External mode info */
  helikopter_ex3_M->Sizes.checksums[0] = (2823378738U);
  helikopter_ex3_M->Sizes.checksums[1] = (1916097514U);
  helikopter_ex3_M->Sizes.checksums[2] = (3588017067U);
  helikopter_ex3_M->Sizes.checksums[3] = (3704185180U);

  {
    static const sysRanDType rtAlwaysEnabled = SUBSYS_RAN_BC_ENABLE;
    static RTWExtModeInfo rt_ExtModeInfo;
    static const sysRanDType *systemRan[1];
    helikopter_ex3_M->extModeInfo = (&rt_ExtModeInfo);
    rteiSetSubSystemActiveVectorAddresses(&rt_ExtModeInfo, systemRan);
    systemRan[0] = &rtAlwaysEnabled;
    rteiSetModelMappingInfoPtr(helikopter_ex3_M->extModeInfo,
      &helikopter_ex3_M->SpecialInfo.mappingInfo);
    rteiSetChecksumsPtr(helikopter_ex3_M->extModeInfo,
                        helikopter_ex3_M->Sizes.checksums);
    rteiSetTPtr(helikopter_ex3_M->extModeInfo, rtmGetTPtr(helikopter_ex3_M));
  }

  helikopter_ex3_M->solverInfoPtr = (&helikopter_ex3_M->solverInfo);
  helikopter_ex3_M->Timing.stepSize = (0.002);
  rtsiSetFixedStepSize(&helikopter_ex3_M->solverInfo, 0.002);
  rtsiSetSolverMode(&helikopter_ex3_M->solverInfo, SOLVER_MODE_SINGLETASKING);

  /* block I/O */
  helikopter_ex3_M->ModelData.blockIO = ((void *) &helikopter_ex3_B);

  {
    helikopter_ex3_B.KalibrerElev = 0.0;
    helikopter_ex3_B.Add = 0.0;
    helikopter_ex3_B.KalibrerPitch = 0.0;
    helikopter_ex3_B.VandringLavpass = 0.0;
    helikopter_ex3_B.KalibrerVandring = 0.0;
    helikopter_ex3_B.K_ei = 0.0;
    helikopter_ex3_B.SatB = 0.0;
    helikopter_ex3_B.Sat = 0.0;
    helikopter_ex3_B.Add_j = 0.0;
  }

  /* parameters */
  helikopter_ex3_M->ModelData.defaultParam = ((real_T *)&helikopter_ex3_P);

  /* states (continuous) */
  {
    real_T *x = (real_T *) &helikopter_ex3_X;
    helikopter_ex3_M->ModelData.contStates = (x);
    (void) memset((void *)&helikopter_ex3_X, 0,
                  sizeof(X_helikopter_ex3_T));
  }

  /* states (dwork) */
  helikopter_ex3_M->ModelData.dwork = ((void *) &helikopter_ex3_DW);
  (void) memset((void *)&helikopter_ex3_DW, 0,
                sizeof(DW_helikopter_ex3_T));

  {
    int_T i;
    for (i = 0; i < 8; i++) {
      helikopter_ex3_DW.HILInitialize_AIMinimums[i] = 0.0;
    }
  }

  {
    int_T i;
    for (i = 0; i < 8; i++) {
      helikopter_ex3_DW.HILInitialize_AIMaximums[i] = 0.0;
    }
  }

  {
    int_T i;
    for (i = 0; i < 8; i++) {
      helikopter_ex3_DW.HILInitialize_AOMinimums[i] = 0.0;
    }
  }

  {
    int_T i;
    for (i = 0; i < 8; i++) {
      helikopter_ex3_DW.HILInitialize_AOMaximums[i] = 0.0;
    }
  }

  {
    int_T i;
    for (i = 0; i < 8; i++) {
      helikopter_ex3_DW.HILInitialize_AOVoltages[i] = 0.0;
    }
  }

  {
    int_T i;
    for (i = 0; i < 8; i++) {
      helikopter_ex3_DW.HILInitialize_FilterFrequency[i] = 0.0;
    }
  }

  {
    int_T i;
    for (i = 0; i < 8; i++) {
      helikopter_ex3_DW.HILInitialize_POSortedFreqs[i] = 0.0;
    }
  }

  {
    int_T i;
    for (i = 0; i < 8; i++) {
      helikopter_ex3_DW.HILInitialize_POValues[i] = 0.0;
    }
  }

  helikopter_ex3_DW.HILWriteAnalog_Buffer[0] = 0.0;
  helikopter_ex3_DW.HILWriteAnalog_Buffer[1] = 0.0;

  /* data type transition information */
  {
    static DataTypeTransInfo dtInfo;
    (void) memset((char_T *) &dtInfo, 0,
                  sizeof(dtInfo));
    helikopter_ex3_M->SpecialInfo.mappingInfo = (&dtInfo);
    dtInfo.numDataTypes = 15;
    dtInfo.dataTypeSizes = &rtDataTypeSizes[0];
    dtInfo.dataTypeNames = &rtDataTypeNames[0];

    /* Block I/O transition table */
    dtInfo.B = &rtBTransTable;

    /* Parameters transition table */
    dtInfo.P = &rtPTransTable;
  }

  /* Initialize Sizes */
  helikopter_ex3_M->Sizes.numContStates = (5);/* Number of continuous states */
  helikopter_ex3_M->Sizes.numY = (0);  /* Number of model outputs */
  helikopter_ex3_M->Sizes.numU = (0);  /* Number of model inputs */
  helikopter_ex3_M->Sizes.sysDirFeedThru = (0);/* The model is not direct feedthrough */
  helikopter_ex3_M->Sizes.numSampTimes = (2);/* Number of sample times */
  helikopter_ex3_M->Sizes.numBlocks = (57);/* Number of blocks */
  helikopter_ex3_M->Sizes.numBlockIO = (9);/* Number of block outputs */
  helikopter_ex3_M->Sizes.numBlockPrms = (178);/* Sum of parameter "widths" */
  return helikopter_ex3_M;
}

/*========================================================================*
 * End of Classic call interface                                          *
 *========================================================================*/
