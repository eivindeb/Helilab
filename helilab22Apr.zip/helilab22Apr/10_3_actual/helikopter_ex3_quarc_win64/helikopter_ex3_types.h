/*
 * helikopter_ex3_types.h
 *
 * Code generation for model "helikopter_ex3".
 *
 * Model version              : 1.61
 * Simulink Coder version : 8.6 (R2014a) 27-Dec-2013
 * C source code generated on : Fri Apr 22 13:27:25 2016
 *
 * Target selection: quarc_win64.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: 32-bit Generic
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */
#ifndef RTW_HEADER_helikopter_ex3_types_h_
#define RTW_HEADER_helikopter_ex3_types_h_
#include "rtwtypes.h"
#include "multiword_types.h"

/* Parameters (auto storage) */
typedef struct P_helikopter_ex3_T_ P_helikopter_ex3_T;

/* Forward declaration for rtModel */
typedef struct tag_RTM_helikopter_ex3_T RT_MODEL_helikopter_ex3_T;

#endif                                 /* RTW_HEADER_helikopter_ex3_types_h_ */
