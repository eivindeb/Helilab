function [ c,ceq ] = non_lin_fun(z) 
global N alpha beta lambda_t
c = zeros(N,1);
for i = 1:N
        c(i) = (alpha*exp( -beta*( z(1)-lambda_t)^2 ) - z(5));
end
    ceq = [];
end

